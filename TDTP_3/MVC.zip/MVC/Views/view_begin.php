<!DOCTYPE html>
<html lang="en">
	<head>
		<meta charset="utf-8"/>
		<title> Nobel Prizes</title>
		<link rel="stylesheet" href="Content/css/nobel.css"/>
	</head>
	<body>
		<nav>
			<ul>
				<li><a href="?controller=list&action=last"> Last Nobel Prizes</a></li>
				<li><a href="?controller=set&action=form_add"> Add a Nobel prize</a></li>
				<!-- <li><a href="?controller=list&action=pagination"> All the Nobel Prizes</a></li> -->
				<!-- <li><a href="?controller=search"> Search among te Nobel prizes</a></li> -->
			</ul>
		</nav>

		<header>
			<h1><a href="?"> Nobel Prizes </a></h1>
		</header>

		<main>