<?php require "view_begin.php"; ?>


<h1> 
    <?= e($title) ?> 
</h1>

<p>   
    <?= e($message) ?>
</p>



<?php require "view_end.php"; ?>